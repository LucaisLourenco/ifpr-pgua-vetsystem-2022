<?php

namespace App\Http\Controllers;

use App\Models\Telefone;
use Illuminate\Http\Request;

class TelefoneController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Telefone $telefone)
    {
        //
    }

    public function edit(Telefone $telefone)
    {
        //
    }

    public function update(Request $request, Telefone $telefone)
    {
        //
    }

    public function destroy(Telefone $telefone)
    {
        //
    }
}
