<?php

namespace App\Http\Controllers;

use App\Models\Peso;
use Illuminate\Http\Request;

class PesoController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Peso $peso)
    {
        //
    }

    public function edit(Peso $peso)
    {
        //
    }

    public function update(Request $request, Peso $peso)
    {
        //
    }

    public function destroy(Peso $peso)
    {
        //
    }
}
